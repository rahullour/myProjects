' Create a WMI locator object
Dim oLocator
Set oLocator = CreateObject("WbemScripting.SWbemLocator")

' Connect to the WMI service
Dim oServices
Set oServices = oLocator.ConnectServer(".", "root\cimv2")

' Creating player object
Dim oPlayer
Set oPlayer = CreateObject("WMPlayer.OCX")

' Creating shell object
Dim objShell
Set objShell = CreateObject("WScript.Shell")


' Define speech object
Dim speechObject
Set speechObject = CreateObject("sapi.spvoice")


' Define the full path to NirCmd
Dim strNirCmdPath
strNirCmdPath = """C:\Program Files\BATTERY_ALARM\NirCmd\nircmd.exe"""

' Define system vol
Dim volume
volume = 25

' Calculate volume level in NirCmd scale
Dim nirCmdVolume
nirCmdVolume = 65530 * volume / 100

' Define the NirCmd command to set the volume
Dim strNirCmdCommand
strNirCmdCommand = strNirCmdPath & " setsysvolume " & nirCmdVolume


' Main loop
While True
	' Execute the NirCmd command
	objShell.Run strNirCmdCommand, 0, True  ' Wait for command to finish

	' Check if the command executed successfully
	If Err.Number <> 0 Then
		MsgBox "Error: " & Err.Description
	End If

	
    Dim bCharging
    Dim iRemaining
    Dim iPercent
    Dim oResults
    Set oResults = oServices.ExecQuery("SELECT * FROM Win32_Battery")
    For Each oResult In oResults
        bCharging = (oResult.BatteryStatus = 2)  ' 2 indicates charging
        iRemaining = oResult.EstimatedChargeRemaining
    Next

    ' Calculate battery percentage
    iPercent = iRemaining Mod 100
    If iPercent = 0 Then
        iPercent = 100
    End If

    ' Perform actions based on battery status and percentage
    If bCharging Then
        If iPercent > 99 Then
            ' Battery is fully charged
            speechObject.Speak "Battery is fully charged"
            oPlayer.URL = "C:\Program Files\BATTERY_ALARM\glados_bat_full_2.mp3"
            oPlayer.controls.play
            WScript.Sleep 3000
        ElseIf iPercent > 30 Then
            ' Reset low battery count
            lcount = 0
        End If
    Else
        If iPercent < 10 Then
            ' Battery is extremely low
            speechObject.Speak "Battery is extremely low. Put it on charge."
        ElseIf iPercent = 30 And lcount = 0 Then
            ' Battery is low, show message
			speechObject.Speak "Battery is low. Battery saver activated."
            lcount = 1
        End If
    End If

    ' Check power connection status
    If bCharging And count = 0 Then
        ' Power connected
        speechObject.Speak "Charging"
        count = 1
    ElseIf Not bCharging And count = 1 Then
        ' Power disconnected
        speechObject.Speak "Disconnected"
        count = 0
    End If

    ' Wait for 10 seconds before repeating the loop
    WScript.Sleep 10000
Wend
