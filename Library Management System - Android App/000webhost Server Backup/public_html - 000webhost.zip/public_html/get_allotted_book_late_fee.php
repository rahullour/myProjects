<?php
require 'connect.php';
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);


$mysql_qry="select late_fee from Books_lent";

$select_stat=$con->query($mysql_qry);

if(mysqli_num_rows($select_stat)>0)
{  
 while($row = $select_stat->fetch_assoc()) {
  $late_fee_id= $row["late_fee"]; 
  echo $late_fee_id."\n";
}
}

else
{
    echo "null";
}


$con->close();

 ?>