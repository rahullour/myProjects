<?php
require 'connect.php';
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

$mysql_qry="select yop from Books";

$select_stat=$con->query($mysql_qry);

if(mysqli_num_rows($select_stat)>0)
{  
 while($row = $select_stat->fetch_assoc()) {
  $yop_id= $row["yop"]; 
  echo $yop_id."\n";
}
}

else
{
    echo "null";
}


$con->close();

 ?>