<?php
    $con = mysqli_connect("localhost","id16665084_rahullour","Project?7891","id16665084_library_data");
/*   
if($con)
    {
echo "Connection to local db successfull \n.";
    

    }
    else {
  echo "Connection to local db failed. \n";

    }
    */
   
   
    ?>
