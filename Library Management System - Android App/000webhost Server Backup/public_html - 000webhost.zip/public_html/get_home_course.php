<?php
require 'connect.php';
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

$user_id=$_POST["user_id"];
//$user_id="06914902018";

$mysql_qry="select course from Books where book_name IN (select bookname from Books_lent where id='$user_id')";

$select_stat=$con->query($mysql_qry);

if(mysqli_num_rows($select_stat)>0)
{  
 while($row = $select_stat->fetch_assoc()) {
  $course_id= $row["course"]; 
  echo $course_id."\n";
}
}

else
{
    echo "null";
}


$con->close();

 ?>