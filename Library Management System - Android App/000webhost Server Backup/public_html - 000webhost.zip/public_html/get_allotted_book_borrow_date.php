<?php
require 'connect.php';
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);


$mysql_qry="select borrow_date from Books_lent";

$select_stat=$con->query($mysql_qry);

if(mysqli_num_rows($select_stat)>0)
{  
 while($row = $select_stat->fetch_assoc()) {
  $borrow_date_id= $row["borrow_date"]; 
  echo $borrow_date_id."\n";
}
}

else
{
    echo "null";
}


$con->close();

 ?>