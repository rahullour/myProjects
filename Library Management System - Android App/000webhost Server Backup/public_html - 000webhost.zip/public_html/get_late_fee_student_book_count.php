<?php
require 'connect.php';
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

$mysql_qry="select count(*) As Count,sum(late_fee) AS TotalFee from Books_lent where late_fee>0 group by id";

$select_stat=$con->query($mysql_qry);

if(mysqli_num_rows($select_stat)>0)
{ 
 while($row = $select_stat->fetch_assoc()) 
 {
  $TotalFee_id= $row["TotalFee"]; 
  if($TotalFee_id>0)
  {
    echo $row["Count"]."\n";
  }
 }
  
}

else
{
    echo "null";
}


$con->close();

 ?>