<?php
require 'connect.php';
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

$mysql_qry="select book_name from Books";

$select_stat=$con->query($mysql_qry);

if(mysqli_num_rows($select_stat)>0)
{ 
 while($row = $select_stat->fetch_assoc()) {
  $book_name_id= $row["book_name"]; 
  // echo nl2br($book_name_id);  
  echo $book_name_id."\n";

 
  }
}

else
{
    echo "null";
}


$con->close();

 ?>