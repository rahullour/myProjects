<?php
require 'connect.php';
$user_email=$_POST["user_email"];
$user_otp=$_POST["user_otp"];


$mysql_qry="select pwd from admin where email='$user_email'";

 
$select_stat=$con->query($mysql_qry);

$row = $select_stat -> fetch_array(MYSQLI_NUM);

if(mysqli_num_rows($select_stat)>0)
{  
    echo $row[0];
    $sql = "UPDATE admin SET otp='$user_otp' where  email='$user_email'";
    $update_stat=$con->query($sql);


}
else
{
   echo "null";
}



        $con->close();

 ?>