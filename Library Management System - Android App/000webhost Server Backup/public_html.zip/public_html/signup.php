<?php
require 'connect.php';

 $user_name=$_POST["user_name"];
 $user_id=$_POST["user_id"];
 $user_pwd=$_POST["user_pwd"];
 $user_email=$_POST["user_email"];
$user_email=$_POST["user_email"];
$user_course=$_POST["user_course"];
 
 
 $mysql_qry="select * from user where id='$user_id'  or email='$user_email'";
 
$select_stat=$con->query($mysql_qry);

 // to check if user already exists .
if(mysqli_num_rows($select_stat)>0)
{  
    echo "null";
    
}

else
{
  $mysql_qry="INSERT INTO user (name,id,pwd,email,course) values ('$user_name','$user_id','$user_pwd','$user_email','$user_course')";
$insert_stat=$con->query($mysql_qry);
if($insert_stat === TRUE)
{
    echo $user_name;
}
else
{
     echo "null";
}

    
    
}

        $con->close();
  

 ?>