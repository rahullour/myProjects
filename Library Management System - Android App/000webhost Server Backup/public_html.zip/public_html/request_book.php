<?php
 ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require 'connect.php';

$user_id=$_POST["user_id"];
$book_name=$_POST["book_name"];

//$user_id="06914902018";
//$book_name="Brave New World";
 
 
$mysql_qry1="select * from Books_lent where id='$user_id'"; 
$select_stat1=$con->query($mysql_qry1);

$mysql_qry2="select books_available from Books where book_name='$book_name'"; 
$select_stat2=$con->query($mysql_qry2);
$row2 = $select_stat2 -> fetch_array(MYSQLI_NUM);

$mysql_qry3="select * from Books_requests where bookname='$book_name' and id='$user_id'"; 
$select_stat3=$con->query($mysql_qry3);
$row3 = $select_stat3 -> fetch_array(MYSQLI_NUM);

$mysql_qry4="select * from Books_lent where bookname='$book_name' and id='$user_id'"; 
$select_stat4=$con->query($mysql_qry4);
$row4 = $select_stat4 -> fetch_array(MYSQLI_NUM);

$mysql_qry5="select * from Books_requests where id='$user_id'"; 
$select_stat5=$con->query($mysql_qry5);


if(mysqli_num_rows($select_stat4)>0)
{
  echo "acquired";
}

else
{



if(mysqli_num_rows($select_stat3)>0)
{	
  echo "exists";
}

else
{


if((mysqli_num_rows($select_stat1) + mysqli_num_rows($select_stat5))>5)
{  
  echo "null";
   
  
}
else if($row2[0]==0)
{
   echo "zero";
}
   
else
{
 
  


 $mysql_qry="INSERT INTO Books_requests (bookname,id) values ('$book_name','$user_id')";
$insert_stat=$con->query($mysql_qry);

if($insert_stat === TRUE)
{   
    echo "success"."\n";
       
    echo $row2[0]-1;

  
}
else
{
    echo "null";
}

  
    
}
}
}

        $con->close();
  

 ?>