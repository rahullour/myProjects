<?php
    $con = mysqli_connect("localhost","id18971716_library_data_rahul","Linuxgold@789","id18971716_library_data");
 /* 
if($con)
    {
echo "Connection to local db successfull \n.";
    

    }
    else {
  echo "Connection to local db failed. \n";

    }
    
   */
   
    ?>
