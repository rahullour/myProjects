<?php
 ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require 'connect.php';

$user_id=$_POST["user_id"];
$book_name=$_POST["book_name"];

//$user_id="06914902018";
//$book_name="Brave New World";
 
 
$mysql_qry="select * from Books_lent where id='$user_id'"; 
$select_stat1=$con->query($mysql_qry);
$row1 = $select_stat1 -> fetch_array(MYSQLI_NUM);





if(mysqli_num_rows($select_stat1)>5)
{  
  echo "null"."\n";
  
   
  
}
   
else
{
 
       
  $mysql_qry1 = "UPDATE Books SET books_available=books_available+1 WHERE book_name='$book_name'"; 
  $update_stat1=$con->query($mysql_qry1);
  
  $mysql_qry4 = "UPDATE user SET books_taken=books_taken-1 WHERE id='$user_id'"; 
  $update_stat4=$con->query($mysql_qry4);
  
  $mysql_qry2="DELETE FROM Books_lent WHERE id='$user_id' and bookname='$book_name'";

  $select_stat2=$con->query($mysql_qry2);
  
  $mysql_qry3="DELETE FROM Books_return_requests WHERE id='$user_id' and bookname='$book_name'";

$select_stat3=$con->query($mysql_qry3);

  
  
  echo $row2[0]+1;

  
}

  
$con->close();
  

 ?>