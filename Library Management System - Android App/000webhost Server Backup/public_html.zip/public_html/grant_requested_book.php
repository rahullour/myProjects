<?php
 ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require 'connect.php';

$user_id=$_POST["user_id"];
$book_name=$_POST["book_name"];

//$user_id="06914902018";
//$book_name="Brave New World";
 
 
$mysql_qry="select * from Books_lent where id='$user_id'"; 
$select_stat1=$con->query($mysql_qry);
$row1 = $select_stat1 -> fetch_array(MYSQLI_NUM);

$mysql_qry="select books_available from Books where book_name='$book_name'"; 
$select_stat2=$con->query($mysql_qry);
$row2 = $select_stat2 -> fetch_array(MYSQLI_NUM);


if(mysqli_num_rows($select_stat1)>5 or $row2[0]==0)
{  
  echo "null"."\n";
  
   
  
}
   
else
{
 
  $borrow_date =date("Y/m/d");
$return_date=Date('y/m/d', strtotime('+7 days'));


 $mysql_qry="INSERT INTO Books_lent (bookname,id,borrow_date,return_date) values ('$book_name','$user_id','$borrow_date','$return_date')";
$insert_stat=$con->query($mysql_qry);

if($insert_stat === TRUE)
{   
   // echo "success"."\n";
       
  $mysql_qry = "UPDATE Books SET books_available=books_available-1 WHERE book_name='$book_name'"; 
  $update_stat=$con->query($mysql_qry);
  
  $mysql_qry1 = "UPDATE user SET books_taken=books_taken+1 WHERE id='$user_id'"; 
  $update_stat1=$con->query($mysql_qry1);
  
  $mysql_qry="DELETE FROM Books_requests WHERE id='$user_id' and bookname='$book_name'";

$select_stat=$con->query($mysql_qry);

if ($con->query($mysql_qry) === TRUE) {
  // echo "success";
} 
else
{
    echo "null";
}
 
  
  
  echo $row2[0]-1;

  
}
else
{
     echo "null".$con->error;
}

  
    
}

        $con->close();
  

 ?>