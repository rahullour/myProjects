<?php
require 'connect.php';
$user_idoremail=$_POST["user_id"];
$user_pwd=$_POST["user_pwd"];

// $user_idoremail="rahulbidawas@gmail.com";
// $user_pwd="123456789";

$mysql_qry1="select * from user where id='$user_idoremail' or email='$user_idoremail'";

$select_stat1=$con->query($mysql_qry1);



if(mysqli_num_rows($select_stat1)>0)
{  
  $mysql_qry="select * from user where pwd='$user_pwd'";

 
$select_stat=$con->query($mysql_qry);



if(mysqli_num_rows($select_stat)>0)
{  
  
  while($row = $select_stat->fetch_assoc()){
  
   echo  $row["name"]."\n";
  echo $row["course"]."\n"; 
    echo $row["id"]; 
  
  }

  
}
  
 
  
  
else
{
    echo "null";
}

  
  
} 
  
else
{
    echo "register";
}







        $con->close();

 ?>