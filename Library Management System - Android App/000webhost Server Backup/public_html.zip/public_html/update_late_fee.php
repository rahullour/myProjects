<?php
require 'connect.php';
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);



 $current_date =date_create(date("Y-m-d"));


$mysql_qry="select return_date,bookname from Books_lent";

 
$select_stat=$con->query($mysql_qry);

if(mysqli_num_rows($select_stat)>0)
{  
 while($row = $select_stat->fetch_assoc()) {
  
  $return_date= $row["return_date"];
  $return_date_id=date_create($return_date);
   $bookname=$row["bookname"];
 
//  echo "Current:".$current_date->format('Y-m-d')."--Return:".$return_date_id->format('Y-m-d')."<br>";
  $diff=date_diff($return_date_id,$current_date);
 // echo $diff->format("%R%a")."<br>";
   $diff=$diff->format("%R%a");
   
if($diff>0)
 {  // echo "inside";  
    $amount=$diff*10;
    $mysql_qry = "UPDATE Books_lent SET late_fee='$amount'  WHERE return_date='$return_date' and bookname='$bookname' and id='$user_id'";
    $update_stat=$con->query($mysql_qry);


if( $con -> affected_rows <0)
{  
    echo "null";
}

     
   }
  
   
  }
}

$con->close();

 ?>