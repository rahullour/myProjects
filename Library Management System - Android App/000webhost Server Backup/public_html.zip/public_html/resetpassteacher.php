<?php
require 'connect.php';
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
 $user_otp=$_POST["user_otp"];
 $user_resetpass=$_POST["user_resetpass"];
 $user_otp_replace=$_POST["user_otp_replace"];
 $user_email=$_POST["user_email"];

 //$user_otp="lqwncurvDS";
 //$user_resetpass="1234567890";
 //$user_otp_replace="replacedotp";

// check otp
$sql1 = "SELECT * FROM admin WHERE otp='$user_otp'";
$result1 = $con->query($sql1);

if ($result1->num_rows > 0) {
  // check is new pass is same as old 
  $sql2 = "SELECT * FROM admin WHERE email='$user_email' and pwd='$user_resetpass'";
$result2 = $con->query($sql2);

if ($result2->num_rows > 0) {
    echo "same";
  }
else {
  //update pwd
  $mysql_qry1 = "UPDATE admin SET pwd='$user_resetpass' WHERE otp='$user_otp'";
 
 $update_stat1=$con->query($mysql_qry1);
  //update otp to avoid otp more than one usage
  $mysql_qry2 = "UPDATE admin SET otp='$user_otp_replace' WHERE otp='$user_otp'";
 
 $update_stat2=$con->query($mysql_qry2);
  
  echo "success";

}
  }
else {
  
  echo "null";
  
}

$con->close();

 ?>