<?php
require 'connect.php';
$user_id=$_POST["user_id"];
$mysql_qry="select email from user where id='$user_id'";

 
$select_stat=$con->query($mysql_qry);

$row = $select_stat -> fetch_array(MYSQLI_NUM);

if(mysqli_num_rows($select_stat)>0)
{  
    echo $row[0];
}
else
{
    echo "null";
}



        $con->close();

 ?>