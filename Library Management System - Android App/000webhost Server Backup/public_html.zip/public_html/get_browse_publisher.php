<?php
require 'connect.php';
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

$mysql_qry="select publisher from Books";

$select_stat=$con->query($mysql_qry);

if(mysqli_num_rows($select_stat)>0)
{  $i=0;
 while($row = $select_stat->fetch_assoc()) {
  $publisher_id= $row["publisher"]; 
  echo $publisher_id."\n";
  $i++;
}
}

else
{
    echo "null";
}


$con->close();

 ?>