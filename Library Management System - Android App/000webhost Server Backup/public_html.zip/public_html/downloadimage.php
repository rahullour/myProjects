<?php
require 'connect.php';

 $user_id=$_POST['user_id'];


// Get Image from the Image Directory
$image = @file_get_contents('images/' . $user_id . '.jpeg');

if($image==FALSE)
{
 echo "null";
}
else
{
    // Encode Image data
$data = base64_encode($image);
echo $data;
}

   $con->close();
  
 ?>