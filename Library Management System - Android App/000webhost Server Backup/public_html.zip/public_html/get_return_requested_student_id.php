<?php
require 'connect.php';
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);


$mysql_qry="select id from Books_return_requests";

$select_stat=$con->query($mysql_qry);

if(mysqli_num_rows($select_stat)>0)
{ 
 while($row = $select_stat->fetch_assoc()) {
  $id_id= $row["id"]; 
  // echo nl2br($bookname_id);  
  echo $id_id."\n";

 
  }
}

else
{
    echo "null";
}


$con->close();

 ?>