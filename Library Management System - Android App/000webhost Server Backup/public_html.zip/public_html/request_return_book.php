<?php
 ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require 'connect.php';

$user_id=$_POST["user_id"];
$book_name=$_POST["book_name"];

//$user_id="06914902018";
//$book_name="Brave New World";
 

$mysql_qry="INSERT INTO Books_return_requests (bookname,id) values ('$book_name','$user_id')";
$insert_stat=$con->query($mysql_qry);

if($insert_stat === TRUE)
{   
    echo "success"."\n";  
}
else
{
    echo "null";
}


        $con->close();
  

 ?>