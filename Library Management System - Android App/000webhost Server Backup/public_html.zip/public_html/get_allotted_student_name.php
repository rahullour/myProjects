<?php
require 'connect.php';
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

$mysql_qry="select id from Books_lent";

$select_stat=$con->query($mysql_qry);





$data = array();
if(mysqli_num_rows($select_stat)>0)
{  
 while($row = $select_stat->fetch_assoc()) {
   $data[] = $row["id"]; 
  
}
 foreach ($data as $value) {
   $mysql_qry1="select name from user where id='$value'";
   $select_stat1=$con->query($mysql_qry1);
   while($row1 = $select_stat1->fetch_assoc()) {
   echo $row1["name"]."\n"; 
  
}
 
}
}else
{
    echo "null";
}


$con->close();

 ?>