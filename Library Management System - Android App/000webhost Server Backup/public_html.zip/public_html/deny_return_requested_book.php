<?php
require 'connect.php';
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);



$user_id=$_POST["user_id"];
$book_name=$_POST["book_name"];

$mysql_qry="delete from Books_return_requests where id='$user_id' and bookname='$book_name'";

$select_stat=$con->query($mysql_qry);

if ($con->query($mysql_qry) === TRUE) {
  echo "success";
}
else
{
    echo "null";
}


$con->close();

 ?>