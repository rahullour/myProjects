<?php
require 'connect.php';
// receive image as POST Parameter
$image = $_POST['image'];
$user_id=$_POST['user_id'];


// Decode the Base64 encoded Image
$data = base64_decode($image);

// Create Image path with Image name and Extension
$file = 'images/' . $user_id . '.jpeg';

// Save Image in the Image Directory
$success = file_put_contents($file, $data);

   $con->close();
 ?>