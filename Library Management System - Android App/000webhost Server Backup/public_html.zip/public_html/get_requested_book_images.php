<?php
require 'connect.php';
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);


$mysql_qry="select bookname from Books_requests";

 
$select_stat=$con->query($mysql_qry);
//$row = $select_stat->fetch_assoc()


if(mysqli_num_rows($select_stat)>0)
{ // $i=0;
 while($row = $select_stat->fetch_assoc()) {
  // $i++;
  $image_id= $row["bookname"]; // Print a single column data
   // Get Image from the Image Directory
 $image = @file_get_contents('browse_book_images/' . $image_id . '.jpg');
   if($image==FALSE)
{

 echo $image_id."=null<br>";
}
else
{
    // Encode Image data
$data = base64_encode($image);
echo $data."\n";
} 
   
 
 }
 //echo "Row Count:".$i;
}
else
{
    echo "null";
}


$con->close();

 ?>