<?php
 ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require 'connect.php';

 $user_id=$_POST["user_id"];
 $book_name=$_POST["book_name"];

// $user_id="06914902018";
// $book_name="Hidden Lang Of Computer Hardware & Software";
 
 
$mysql_qry="delete from Books_lent where id='$user_id' and bookname='$book_name'"; 
$select_stat=$con->query($mysql_qry);

if($select_stat === TRUE)
{   
    echo "success"."\n";
       
  $mysql_qry = "UPDATE Books SET books_available=books_available+1 WHERE book_name='$book_name'"; 
  $update_stat=$con->query($mysql_qry); 
}
else
{
     echo "null";
    // echo $con->error;
}  
    


        $con->close();
  

 ?>