<?php
 ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require 'connect.php';

$user_id=$_POST["user_id"];
$book_name=$_POST["book_name"];

//$user_id="06914902018";
//$book_name="Brave New World";
 
 
$mysql_qry1="select * from Books_lent where id='$user_id' and bookname='$book_name'"; 
$select_stat1=$con->query($mysql_qry1);


if(mysqli_num_rows($select_stat1)>0)
{  
 
  $mysql_qry2="delete from Books_lent where id='$user_id' and bookname='$book_name'";

$select_stat2=$con->query($mysql_qry2);
  
  $mysql_qry5="select * from Books_return_requests where id='$user_id' and bookname='$book_name'"; 
$select_stat5=$con->query($mysql_qry5);
  
  if(mysqli_num_rows($select_stat5)>0)
{  
    $mysql_qry6="delete from Books_return_requests where id='$user_id' and bookname='$book_name'";

$select_stat6=$con->query($mysql_qry6);
    
  }
  
  
     
   $mysql_qry3 = "UPDATE Books SET books_available=books_available+1 WHERE book_name='$book_name'"; 
  $update_stat3=$con->query($mysql_qry3);
  
  $mysql_qry7 = "UPDATE user SET books_taken=books_taken-1 WHERE id='$user_id'"; 
  $update_stat7=$con->query($mysql_qry7);
  
  $mysql_qry4="select books_available from Books where book_name='$book_name'"; 
$select_stat4=$con->query($mysql_qry4);
$row4 = $select_stat4 -> fetch_array(MYSQLI_NUM);
  
  echo $row4[0]."\n";
  echo "success";
  
  
}
   
else
{
     echo "null";
}

  
    


        $con->close();
  

 ?>